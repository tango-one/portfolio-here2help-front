// styles
import "./style.css";

const index = () => {
  return (
    <div className="contact__message">
      <p>Email received, we will contact you as soon as possible</p>
    </div>
  );
};

export default index;
